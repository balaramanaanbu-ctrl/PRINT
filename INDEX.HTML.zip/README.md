# Print Service - GitHub Pages Website

This is a ready-to-upload static website for **Print Service**. It includes separate pages for Terms, Refunds, and Contact which are required for payment gateway verification.

## How to deploy
1. Download the ZIP and extract the folder.
2. Create a new GitHub repository (public).
3. Upload all files and the `images/` folder to the repository root.
4. In the repository, go to Settings → Pages, choose the `main` branch and root (`/`) as the source.
5. Save and wait a minute — your site will be live at `https://<your-username>.github.io/<repo>/`.

## Edit contact details
Update `contact.html` or the `contact_text` in the code before re-generating if you need to change merchant details.
